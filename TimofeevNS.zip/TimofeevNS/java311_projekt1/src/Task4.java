import java.util.Scanner;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Task4 {



    public static void main(String[] args) {
        // Задание 4
        System.out.println("Введите число - ");
        Scanner scanner = new Scanner(System.in);
        int number =  scanner.nextInt();


        if (number >= 0 && number< 6){
            System.out.println("God Night!");
        }
        if (number >= 6 && number< 13){
            System.out.println("God Night!");
        }
        if (number >= 13 && number< 17){
            System.out.println("God Day!");
        }
        if (number >= 17 && number < 24){
            System.out.println("God Day!");
        }
        else
            System.out.println("Некоректное число!");

    }



}