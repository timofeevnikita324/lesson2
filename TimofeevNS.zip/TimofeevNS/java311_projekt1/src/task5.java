import java.util.Scanner;

public class task5 {
    public static void main(String[] args){
        while(true) {
            System.out.println("Введите число - ");
            Scanner scanner = new Scanner(System.in);
            String numberStr= scanner.nextLine();
            if (numberStr.length() != 6)
                System.out.println("Число не шестезначное!");
            else {
                int number = Integer.parseInt(numberStr);
                int ferstHalf = number / 1000;


                int secondHalf = number % 1000;


                int sumFerstHalf = (ferstHalf % 10) + (ferstHalf / 100) + ((ferstHalf / 100) % 10);
                int sumSecondHalf = (secondHalf % 10) + (secondHalf / 100) + ((secondHalf / 100) % 10);

                if (sumFerstHalf == sumSecondHalf)
                    System.out.println("Число счастливое");
                else
                    System.out.println("Число не счастливое");
            }
        }
    }
}
