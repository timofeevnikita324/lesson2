import java.util.Scanner;

public class task6 {
    public static void main(String[] args) {

        System.out.println("Введите число от 1 до 100 - ");
        Scanner scanner = new Scanner(System.in);
        int number = scanner.nextInt();
        if(number  < 1 || number > 100)
            System.out.println("Некоректное число!");
        else {
            if(number % 3 == 0 && number % 5 == 0)
                System.out.println("Fizz Buzz");
            else
            if(number % 3 == 0)
                System.out.println("Fizz");

            else
            if (number % 5 == 0)
                System.out.println("Buzz");

            else
            if(number % 3 != 0 && number % 5 != 0)
                System.out.println(number);
        }
    }
}
