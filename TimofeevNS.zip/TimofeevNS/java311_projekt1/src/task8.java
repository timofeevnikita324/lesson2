import java.util.Scanner;
import java.util.regex.Matcher;

public class task8 {
    public static void main(String[] args) {
        System.out.println("Введите начало диапазона  - ");
        Scanner scanner = new Scanner(System.in);
        int number1 = scanner.nextInt();

        System.out.println("Введите конец диапазона  - ");
        int number2 = scanner.nextInt();

        for(int i = number1; i <= number2; i++)
        {
            if (i == 1 || i == 2 || i == 3){
                System.out.println("Число простое!");
            }

            if(i % 2 == 0 && i % 3 == 0)
            {
                System.out.println("Число сложное!");
            }
            else
                System.out.println("Число простое!");


        }
    }
}
